#ifndef VEDNNX_H_
#define VEDNNX_H_

/** libvednn public and internal api have slightly different argument
 * ordering.  The iterator api of libvednnx must follow the libvednn
 * low-level convention!  So provide macros to combine parms and arguments
 * in the correct order for either call.
 *
 * ### Guiding principle
 *
 * Order of parameter and data arguments follows libvednn public call API
 * as in \ref vednn.h.  We split parameters from data. Then we give
 * macros to combine parameters and data to be able to call the libvednn
 * monolithic wrapper, OR low-level routines of libvednn exposed by the
 * libvednnx iterator interface.
 *
 * User should arrange arguments always in \ref vednn.h order, shunting
 * through re-order macros.
 *
 * - Two reordering macros are useful:
 *   - If you want to write out all parameters, use the CONV_FOO_ORDER_(lots of args) macro
 *   - If you #define'd two parameter packs, use CONV_FOO_ORDER(PARMS,DATA) macro
 *
 * Ex Forward has order of parameters PK, ...
 */

/** expand macro args, then reorder them for libvednn public interface.
 * These re-orderings can be written based on \ref vednn.h alone. */
#define CONV_FWD_ORDER(...) CONV_FWD_ORDER_(__VA_ARGS__)
#define CONV_FWD_ORDER_(PI,PK,PO,PC,ALGO,   DI,DK,DO) /* reorder for libvednn public interface */ \
	PI,DI, PK,DK, PO,DO, PC,ALGO

#define CONV_FWDB_ORDER(...) CONV_FWDB_ORDER_(__VA_ARGS__)
#define CONV_FWDB_ORDER_(PI,PK,PB,PO,PC,ALGO,   DI,DK,DB,DO) /* reorder for libvednn public interface */ \
	PI,DI, PK,DK, PB,DB, PO,DO, PC,ALGO

/** expand macro args, then reorder them for libvednnx iter->impl calls.
 *
 * While the libvednnx _Begin().._End() api accepts \ref vednn.h ordering
 * of the \em parameter arguments, when you \b call (*Iter_impl) you need an
 * arrangement of args that does not quite match \ref vednn.h (\em annoying!)
 *
 * While above orderings were from \ref vednn.h, CONVX_* macros mimic
 * low-level conventions like ine \ref src/C/vednnConvolutionForward.h
 *
 * (Order differs, and the vednnConvolutionAlgorithm_t arg is absent)
 */
#define CONVX_FWD_ORDER(...) CONVX_FWD_ORDER_(__VA_ARGS__)
#define CONVX_FWD_ORDER_(PI,PK,PO,PC,ALGO,   DI,DK,DO) /* reorder for libvednn low-level call */ \
	PI,DI, PK,DK, PC, PO,DO

#define CONVX_FWDB_ORDER(...) CONVX_FWDB_ORDER_(__VA_ARGS__)
#define CONVX_FWDB_ORDER_(PI,PK,PB,PO,PC,ALGO,   DI,DK,DB,DO) /* reorder for libvednn low-level call */ \
	PI,DI, PK,DK, PB,DB, PC, PO,DO

#include "wrap/vednnConvolutionLists.h" // well parts should be public, like the Begin,Next api

// vim: et ts=4 sw=4 cindent cino=^=l0,\:0,N-s
#endif // VEDNNX_H_
