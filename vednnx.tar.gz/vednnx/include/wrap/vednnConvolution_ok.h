#ifndef VEDNNCONVOLUTION_OK_H
#define VEDNNCONVOLUTION_OK_H
/** \file
 * This file declares "ok" precondition checkers on convolution descriptors
 */
#include "vednn.h"
#include "wrap/vednnImpl_args.h"

#ifdef __cplusplus
extern "C" {
#endif /*}*/

/** parameter order follows \ref vednn.h (just remove the pDataXXX args).
 * There are slight differences for \e restrict keyword. */
typedef vednnError_t vednnConvForward_okfn_decl(
        VEDNN_PARAMS_CONV_FORWARD );
typedef vednnConvForward_okfn_decl * vednnConvForward_okfn_t;

typedef vednnError_t vednnConvForward_rtokfn_decl(
        VEDNN_DATARG_CONV_FORWARD );
//typedef vednnConvForward_rtokfn_decl * vednnConvForward_rtokfn_t;
typedef vednnError_t (*vednnConvForward_rtokfn_t)(VEDNN_DATARG_CONV_FORWARD);

typedef vednnError_t vednnConvForwardAddBias_okfn_decl(
        VEDNN_PARAMS_CONV_FORWARDADDBIAS );
typedef vednnConvForwardAddBias_okfn_decl* vednnConvForwardAddBias_okfn_t;

typedef vednnError_t vednnConvBackwardData_okfn_decl(
        VEDNN_PARAMS_CONV_BACKWARD_DATA );
typedef vednnConvBackwardData_okfn_decl * vednnConvBackwardData_okfn_t;

typedef vednnError_t vednnConvBackwardFilter_okfn_decl(
        VEDNN_PARAMS_CONV_BACKWARD_FILTER );
typedef vednnConvBackwardFilter_okfn_decl * vednnConvBackwardFilter_okfn_t;

//vednnError_t (*vednnConvolutionForward_direct_dil1_str1_pad0_ker3_iw2X_ow2XU256_ioaligned_rtok) (VEDNN_DATARG_CONV_FORWARD);

#define FWD_FN_OK(BASENAME) vednnConvForward_okfn_decl BASENAME##_ok; \
    extern vednnError_t (*BASENAME##_rtok) (VEDNN_DATARG_CONV_FORWARD)
    //vednnConvForward_rtokfn_t BASENAME##_rtok  // XXX WHY NOT XXX XXX
FWD_FN_OK(vednnConvolutionForward_direct_dil1_str1_padsame_ker3_c1_owU128);
FWD_FN_OK(vednnConvolutionForward_direct_dil1_str1_padsame_ker3_c1024x);
FWD_FN_OK(vednnConvolutionForward_direct_dil1_str1_padsame_ker3);
FWD_FN_OK(vednnConvolutionForward_direct_dil1_str1_padsame);
FWD_FN_OK(vednnConvolutionForward_direct_dil1_str1_padsame_ker3_c1);
FWD_FN_OK(vednnConvolutionForward_direct_dil1_str1_pad0_ker1_c1024x);
FWD_FN_OK(vednnConvolutionForward_direct_dil1_str1_pad0_ker1);
FWD_FN_OK(vednnConvolutionForward_direct_dil1_str1_pad0_ker3_iw2X_ow2XU256_ioaligned);
FWD_FN_OK(vednnConvolutionForward_direct_dil1_str1_pad0_owU128);
FWD_FN_OK(vednnConvolutionForward_direct_dil1_str1_pad0);
FWD_FN_OK(vednnConvolutionForward_direct_owU128);
FWD_FN_OK(vednnConvolutionForward_direct_default2);
FWD_FN_OK(vednnConvolutionForward_direct_default);
#undef FWD_FN_OK
#define FWDBIAS_FN_OK(BASENAME) vednnConvForwardAddBias_okfn_decl BASENAME##_ok;
FWDBIAS_FN_OK(vednnConvolutionForwardAddBias_direct_dil1_str1_pad0_ker1_c1024x);
FWDBIAS_FN_OK(vednnConvolutionForwardAddBias_direct_dil1_str1_pad0_ker1);
FWDBIAS_FN_OK(vednnConvolutionForwardAddBias_direct_dil1_str1_padsame_ker3_c1_owU128);
FWDBIAS_FN_OK(vednnConvolutionForwardAddBias_direct_dil1_str1_padsame_ker3_c1024x);
FWDBIAS_FN_OK(vednnConvolutionForwardAddBias_direct_dil1_str1_padsame_ker3_c1);
FWDBIAS_FN_OK(vednnConvolutionForwardAddBias_direct_dil1_str1_padsame_ker3);
FWDBIAS_FN_OK(vednnConvolutionForwardAddBias_direct_dil1_str1_padsame);
FWDBIAS_FN_OK(vednnConvolutionForwardAddBias_direct_default);
#undef FWDBIAS_FN_OK
#define BKWD_FN_OK(BASENAME) vednnConvBackwardData_okfn_decl BASENAME##_ok
BKWD_FN_OK(vednnConvolutionBackwardData_direct_dil1_str1_padsame); // really up top?
BKWD_FN_OK(vednnConvolutionBackwardData_direct_dil1_str1_pad0_ker3_iw2XU256_ow2X_ioaligned);
BKWD_FN_OK(vednnConvolutionBackwardData_direct_dil1_str1_pad0_ker3_iwU128);
BKWD_FN_OK(vednnConvolutionBackwardData_direct_dil1_str1_iwU128);
BKWD_FN_OK(vednnConvolutionBackwardData_direct_dil1_str1);
BKWD_FN_OK(vednnConvolutionBackwardData_direct_iwU128);
BKWD_FN_OK(vednnConvolutionBackwardData_direct_default);
#undef BKWD_FN_OK
#define BKWF_FN_OK(BASENAME) vednnConvBackwardData_okfn_decl BASENAME##_ok
BKWF_FN_OK(vednnConvolutionBackwardFilter_direct_dil1_str1_padsame_ker1);
BKWF_FN_OK(vednnConvolutionBackwardFilter_direct_dil1_str1_padsame_ker3);
BKWF_FN_OK(vednnConvolutionBackwardFilter_direct_dil1_str1_padsame);
BKWF_FN_OK(vednnConvolutionBackwardFilter_direct_dil1_str1_pad0_ker3_ow2XU128_iw2X_igoaligned);
BKWF_FN_OK(vednnConvolutionBackwardFilter_direct_dil1_pad0_ker3_owU128);
BKWF_FN_OK(vednnConvolutionBackwardFilter_direct_dil1_pad0_owU128);
BKWF_FN_OK(vednnConvolutionBackwardFilter_direct_dil1_pad0);
BKWF_FN_OK(vednnConvolutionBackwardFilter_direct_dil1_pad0);
BKWF_FN_OK(vednnConvolutionBackwardFilter_direct_owU128);
BKWF_FN_OK(vednnConvolutionBackwardFilter_direct_default);
#undef BKWF_FN_OK
#ifdef __cplusplus /*{*/
}
#endif
// vim: et ts=4 sw=4 cindent cino=^=l0,\:0,N-s
#endif // VEDNNCONVOLUTION_OK_H
