#ifndef VEDNNCONVOLUTION_OK_H
#define VEDNNCONVOLUTION_OK_H
/** \file
 * This file declares "ok" precondition checkers on convolution descriptors
 * Checking can proceed in two phases:
 *
 * 1. Compile-time conditions based on PARAMS that describe the operation,
 *    like array sizes, padding, or other optional layer features.
 *
 * 2. Run-time conditions that check DATARG [and PARAMS] for things
 *    like alignment restrictions on pointer[s] into data tensors.
 *    Failed alignment checks then may choose an alternate impl with
 *    relaxed tenosr alignment requirements.
 *
 * - \ref vednnConvolutionLists.h or \b _Begin/_Next/_ok and \b _realNext/_rtok
 *        iteration functions.
 */
#include "vednn.h"
#include "wrap/vednnImpl_args.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif /*}*/

/** parameter order follows \ref vednn.h (just remove the pDataXXX args).
 * There are slight differences for \e restrict keyword. */
#define DECLARE_OK_FNS(Forward,FORWARD) \
typedef vednnError_t   vednnConv##Forward##_okfn_decl(  VEDNN_PARAMS_CONV_##FORWARD); \
typedef                vednnConv##Forward##_okfn_decl * vednnConv##Forward##_okfn_t; \
typedef vednnError_t   vednnConv##Forward##_rtokfn_decl(VEDNN_DATARG_CONV_##FORWARD); \
typedef vednnError_t (*vednnConv##Forward##_rtokfn_t)(  VEDNN_DATARG_CONV_##FORWARD);
DECLARE_OK_FNS(Forward,         FORWARD)
DECLARE_OK_FNS(ForwardAddBias,  FORWARDADDBIAS)
DECLARE_OK_FNS(BackwardData,    BACKWARD_DATA)
DECLARE_OK_FNS(BackwardFilter,  BACKWARD_FILTER)
#undef DECLARE_OK_FNS

// declare both the _ok and _rtok functioncs
#define FWD_FN_OK(BASENAME) vednnConvForward_okfn_decl BASENAME##_ok;
#define FWD_RT_OK(BASENAME) vednnConvForward_rtokfn_decl BASENAME##_rtok;
FWD_FN_OK(vednnConvolutionForward_direct_dil1_str1_padsame_ker3_c1_owU128);
FWD_FN_OK(vednnConvolutionForward_direct_dil1_str1_padsame_ker3_c1024x);
FWD_FN_OK(vednnConvolutionForward_direct_dil1_str1_padsame_ker3);
FWD_FN_OK(vednnConvolutionForward_direct_dil1_str1_padsame);
FWD_FN_OK(vednnConvolutionForward_direct_dil1_str1_padsame_ker3_c1);
FWD_FN_OK(vednnConvolutionForward_direct_dil1_str1_padsame_ker5_owU128); //
FWD_FN_OK(vednnConvolutionForward_direct_dil1_str1_padsame_ker5); //
FWD_FN_OK(vednnConvolutionForward_direct_dil1_str1_pad0_ker1_c1024x);
FWD_FN_OK(vednnConvolutionForward_direct_dil1_str1_pad0_ker1);
FWD_FN_OK(vednnConvolutionForward_direct_dil1_str1_pad0_ker3_iw2XU256_ow2X_ioaligned);
FWD_RT_OK(vednnConvolutionForward_direct_dil1_str1_pad0_ker3_iw2XU256_ow2X_ioaligned);
FWD_FN_OK(vednnConvolutionForward_direct_dil1_str1_pad0_owU128);
FWD_FN_OK(vednnConvolutionForward_direct_dil1_str1_pad0);
FWD_FN_OK(vednnConvolutionForward_direct_owU128);
FWD_FN_OK(vednnConvolutionForward_direct_default2);
FWD_FN_OK(vednnConvolutionForward_direct_default3);
FWD_FN_OK(vednnConvolutionForward_direct_default3b);
FWD_FN_OK(vednnConvolutionForward_direct_default);
#undef FWD_FN_OK
#undef FWD_RT_OK
#define FWDBIAS_FN_OK(BASENAME) vednnConvForwardAddBias_okfn_decl BASENAME##_ok;
#define FWDBIAS_RT_OK(BASENAME) vednnConvForwardAddBias_rtokfn_decl BASENAME##_rtok;
FWDBIAS_FN_OK(vednnConvolutionForwardAddBias_direct_dil1_str1_pad0_ker1_c1024x);
FWDBIAS_FN_OK(vednnConvolutionForwardAddBias_direct_dil1_str1_pad0_ker1);
FWDBIAS_FN_OK(vednnConvolutionForwardAddBias_direct_dil1_str1_padsame_ker3_c1_owU128);
FWDBIAS_FN_OK(vednnConvolutionForwardAddBias_direct_dil1_str1_padsame_ker3_c1024x);
FWDBIAS_FN_OK(vednnConvolutionForwardAddBias_direct_dil1_str1_padsame_ker3_c1);
FWDBIAS_FN_OK(vednnConvolutionForwardAddBias_direct_dil1_str1_padsame_ker3);
FWDBIAS_FN_OK(vednnConvolutionForwardAddBias_direct_dil1_str1_padsame);
FWDBIAS_FN_OK(vednnConvolutionForwardAddBias_direct_default);
#undef FWDBIAS_RT_OK
#undef FWDBIAS_FN_OK
#define BKWD_FN_OK(BASENAME) vednnConvBackwardData_okfn_decl BASENAME##_ok;
#define BKWD_RT_OK(BASENAME) vednnConvBackwardData_rtokfn_decl BASENAME##_rtok;
BKWD_FN_OK(vednnConvolutionBackwardData_direct_dil1_str1_padsame_ker5); // new
BKWD_FN_OK(vednnConvolutionBackwardData_direct_dil1_str1_padsame); // really up top?
BKWD_FN_OK(vednnConvolutionBackwardData_direct_dil1_str1_pad0_ker3_iw2XU32_ow2X_ioaligned); // new
BKWD_RT_OK(vednnConvolutionBackwardData_direct_dil1_str1_pad0_ker3_iw2XU32_ow2X_ioaligned); // new
BKWD_FN_OK(vednnConvolutionBackwardData_direct_dil1_str1_pad0_ker3_iw2XU256_ow2X_ioaligned);
BKWD_RT_OK(vednnConvolutionBackwardData_direct_dil1_str1_pad0_ker3_iw2XU256_ow2X_ioaligned);
BKWD_FN_OK(vednnConvolutionBackwardData_direct_dil1_str1_pad0_ker3_iwU128);
BKWD_FN_OK(vednnConvolutionBackwardData_direct_dil1_str1_iwU128);
BKWD_FN_OK(vednnConvolutionBackwardData_direct_dil1_str1);
BKWD_FN_OK(vednnConvolutionBackwardData_direct_iwU128);
BKWD_FN_OK(vednnConvolutionBackwardData_direct_default);
#undef BKWD_RT_OK
#undef BKWD_FN_OK
#define BKWF_FN_OK(BASENAME) vednnConvBackwardFilter_okfn_decl BASENAME##_ok;
#define BKWF_RT_OK(BASENAME) vednnConvBackwardFilter_rtokfn_decl BASENAME##_rtok;
BKWF_FN_OK(vednnConvolutionBackwardFilter_direct_dil1_str1_padsame_ker1);
BKWF_FN_OK(vednnConvolutionBackwardFilter_direct_dil1_str1_padsame_ker3);
BKWF_FN_OK(vednnConvolutionBackwardFilter_direct_dil1_str1_padsame);
BKWF_FN_OK(vednnConvolutionBackwardFilter_direct_dil1_str1_pad0_ker3_ow2X_iw2XU256_igoaligned);
BKWF_RT_OK(vednnConvolutionBackwardFilter_direct_dil1_str1_pad0_ker3_ow2X_iw2XU256_igoaligned);
BKWF_FN_OK(vednnConvolutionBackwardFilter_direct_dil1_pad0_ker3_owU128);
BKWF_FN_OK(vednnConvolutionBackwardFilter_direct_dil1_pad0_owU128);
BKWF_FN_OK(vednnConvolutionBackwardFilter_direct_dil1_pad0);
BKWF_FN_OK(vednnConvolutionBackwardFilter_direct_dil1_pad0);
BKWF_FN_OK(vednnConvolutionBackwardFilter_direct_owU128);
BKWF_FN_OK(vednnConvolutionBackwardFilter_direct_default);
#undef BKWF_RT_OK
#undef BKWF_FN_OK
#ifdef __cplusplus /*{*/
}
#endif
// vim: et ts=4 sw=4 cindent cino=^=l0,\:0,N-s
#endif // VEDNNCONVOLUTION_OK_H
