#ifndef VEDNNCONVOLUTIONLISTS_H
#define VEDNNCONVOLUTIONLISTS_H
#include "wrap/vednnConvolution_ok.h"

#include "C/vednnConvolutionForward.h"
#include "C/vednnConvolutionForwardAddBias.h"
#include "C/vednnConvolutionBackwardData.h"
#include "C/vednnConvolutionBackwardFilter.h"

#include <stddef.h> // NULL

#ifdef __cplusplus
extern "C" {
#endif //}
/** \file
 * \todo make FooImpls opqaque void*, and provide invokers that accept
 *       the void* impls and the vednn.h parameter order,
 *       perform parameter re-ordering,
 *       and call the low-level libvednn impl
 *
 *       i.e. client see XXX_Begin/Next and gets opaque ptr with impl.
 *       Client calls 'XXX_invoke' (or whatever) with the opaque ptr
 *       followed by the normal vednn.h parameters.
 *
 *       XXX_invoke just calls the appropriate low-level impl, re-ordering
 *       parameters as required.
 *
 * Note: for use in external projects like mkl-dnn I still need to expose
 *       the _ok functions and the raw impl lists!
 *       ... but vednnx.h should NOT pull them in be default.
 */

#if 0
#define VEDNNCONVOLUTIONLISTS_FWD_DECL( BASE, DATARGS ) \
/* fwd decl */ \
struct BASE##Impls_s; \
VEDNNCONVOLUTIONLISTS_FWD_DECL( vednnConvForward, VEDNN_DATARG_CONV_FORWARD );
#undef VEDNNCONVOLUTIONLISTS_FWD_DECL
#endif

/** \group Impl Begin/Next API */
//@{
#define ITERATOR_FUNC_API( BASE, BASE_PARAMS, BASE_DATARG ) \
    \
struct BASE##Impls_s; /*fwd decl*/ \
typedef struct BASE##Impls_s BASE##Impls; \
extern BASE##Impls * BASE##List; \
\
BASE##Impls * BASE##_Begin( BASE_PARAMS ); \
\
BASE##Impls * BASE##_Next( BASE##Impls* current, BASE_PARAMS ); \
\
BASE##Impls * BASE##_realNext( BASE##Impls* current, BASE_PARAMS, BASE_DATARG ); \
\
typedef struct { \
    BASE##Impls* actual; \
    vednnError_t status; \
} BASE##_out_t; \
\
BASE##_out_t BASE##_Run( BASE##Impls* current, BASE_PARAMS, BASE_DATARG );

ITERATOR_FUNC_API( vednnConvForward,        VEDNN_PARAMS_CONV_FORWARD,        VEDNN_DATARG_CONV_FORWARD)
ITERATOR_FUNC_API( vednnConvForwardAddBias, VEDNN_PARAMS_CONV_FORWARDADDBIAS, VEDNN_DATARG_CONV_FORWARDADDBIAS)
ITERATOR_FUNC_API( vednnConvBackwardData,   VEDNN_PARAMS_CONV_BACKWARD_DATA,  VEDNN_DATARG_CONV_BACKWARD_DATA)
ITERATOR_FUNC_API( vednnConvBackwardFilter, VEDNN_PARAMS_CONV_BACKWARD_DATA,  VEDNN_DATARG_CONV_BACKWARD_DATA)

// following are TBD:
// there is no backward (reuse the fwd one)
ITERATOR_FUNC_API( vednnLinForward,  VEDNN_PARAMS_LIN_FORWARD,  VEDNN_DATARG_LIN_FORWARD)

ITERATOR_FUNC_API( vednnMaxPoolForward,  VEDNN_PARAMS_MAXPOOL_FORWARD,  VEDNN_DATARG_MAXPOOL_FORWARD)
ITERATOR_FUNC_API( vednnMaxPoolBackward, VEDNN_PARAMS_MAXPOOL_BACKWARD, VEDNN_DATARG_MAXPOOL_BACKWARD)

ITERATOR_FUNC_API( vednnActForward,   VEDNN_PARAMS_ACT_FORWARD,  VEDNN_DATARG_ACT_FORWARD)
ITERATOR_FUNC_API( vednnActBackward,  VEDNN_PARAMS_ACT_BACKWARD, VEDNN_DATARG_ACT_BACKWARD)
#undef ITERATOR_FUNC_API
//@}

/** \addtogroup Impl list elements
 *  These flesh out low-level vednn implementations with some handy info,
 * and some handy auxiliary functions.
 */
//@{    
/** \struct vednnConvForwardImpls_s
 *
 *   \param okfn, returning VEDNN_SUCCESS if parameters seem compatible
 *   \param rtokfn, returning VEDNN_SUCCESS if data ptrs seem compatible
 *   \param impl, a hardwired pointer to the libvednn function
 *   \param name, full name of function
 *   \param shorname, shorter string for function
 *   \param getPd, reserved for future use
 *   \param getImpl, reserved for future use
 *
 * - \c impl arg order does not match public API! There are arg-reordering
 *   macros to handle this nicely.
 *   - \ref C/vednnConvolutionForward.h vs public libvednn api in \ref vednn.h
 *
 * - TODO: newer style convolution functions may wish to precalculate
 *   some private data, \c getPd, which is a function of the parameters
 *   (and will typically also store a verbatim copy of all parameters)
 *   - Then we can return a new style library function that accepts as
 *     arguments the private data, and only the data inputs (no \e pParamFoo
 *     args.
 *   - This means \c impl is null, because a new function signature is used
 *   - The new <em>private data</em> implementation accepts just a \e void*
 *     in lieu of all pParamFoo args, followed by actual tensor data args
 *   - Actually, the new impl is returned via a function call, which allows
 *     the function pointer to be jit-ed at runtime, if desired.
 *
 * - Each newer [or jit] \c impl would NULL, instead using \b two helpers:
 *   - \c getPd, a function taking Params and returning
 *     a single <TT>void*</TT> private data
 *     - private data would typically maintain a copy of all pParamFoo parms
 *     - private data memory could also contain precalculated constant data,
 *       in whatever form best can speed up the implementation.
 *     - Ex. \c vednnConForwardPd_t is a modification of libvednn arguments as
 *       in \ref vednnConvolutionForward.h
 *   - \c getImpl, returning a function that accepts private data, followed by
 *     the usual convolution arguments (just the data arguments, params could be
 *     cached within private data)
 *
 * \todo make okfn, rtokfn and impl void const ptrs, to force iterator API.
 *       Rationale:
 *       User might not do full checks, or might avoid a wrapper that adds
 *       thread support, if he tries to use these ptrs directly. also some
 *       of the fn ptrs can be NULL.
 *
 * \todo working example of getPd+getImpl
 */
//@{

struct vednnConvForwardImpls_s {
    vednnConvForward_t        impl;     ///< vednn library function
    char const*               name;     ///< full name of impl
    char const*          shortname;     ///< shorter label for impl
    vednnConvForward_okfn_t   okfn;     ///< check if PARAMS ok
    vednnConvForward_rtokfn_t rtokfn;   ///< usually NULL, (else check DATA alignment ok)
    void* (*getPd)(VEDNN_PARAMS_CONV_FORWARD); ///< precalc data (for later)
    vednnConvForwardPd_t (*getImpl)(void* pd, VEDNN_PARAMS_CONV_FORWARD); ///< new API
};

struct vednnConvForwardAddBiasImpls_s {
    vednnConvForwardAddBias_t      impl;
    char const* name;
    char const* shortname;
    vednnConvForwardAddBias_okfn_t okfn;
    void * rtok;
    void* (*getPd)(VEDNN_PARAMS_CONV_FORWARDADDBIAS);
    vednnConvForwardPd_t (*getImpl)(void* pd, VEDNN_DATARG_CONV_FORWARDADDBIAS);
};

struct vednnConvBackwardDataImpls_s {
    vednnConvBackwardData_t      impl;
    char const* name;
    char const* shortname;
    vednnConvBackwardData_okfn_t okfn;
    void * rtok;
    void* (*getPd)(VEDNN_PARAMS_CONV_BACKWARD_DATA);
    vednnConvBackwardDataPd_t (*getImpl)(void* pd, VEDNN_DATARG_CONV_BACKWARD_DATA);
};

struct vednnConvBackwardFilterImpls_s {
    vednnConvBackwardFilter_t      impl;
    char const* name;
    char const* shortname;
    vednnConvBackwardFilter_okfn_t okfn;
    void * rtok;
    void* (*getPd)(VEDNN_PARAMS_CONV_BACKWARD_FILTER);
    vednnConvBackwardFilterPd_t (*getImpl)(void* pd, VEDNN_DATARG_CONV_BACKWARD_FILTER);
};

//@}

#if 0
/// \group add _Begin and _Next functions to traverse lists of libvednn impls and helpers
//@{
//
/** find \b first [best? fastest?] {okfn, impl} in list such that \c okfn yields VEDNN_SUCCESS.
 * \return list terminator (all-NULLs) if none. */
vednnConvForwardImpls * vednnConvForward_Begin(
        VEDNN_PARAMS_CONV_FORWARD );
/** return next available implementation, after \c current list item.
 * return list terminator (all-NULLs) if none.
 * \pre \c current points within vednnConvForwardList[]
 */
vednnConvForwardImpls * vednnConvForward_Next(
        vednnConvForwardImpls* current,
        VEDNN_PARAMS_CONV_FORWARD );

vednnConvForwardAddBiasImpls * vednnConvForwardAddBias_Begin(
        VEDNN_PARAMS_CONV_FORWARDADDBIAS );
vednnConvForwardAddBiasImpls * vednnConvForwardAddBias_Next(
        vednnConvForwardAddBiasImpls* current,
        VEDNN_PARAMS_CONV_FORWARDADDBIAS );

vednnConvBackwardDataImpls * vednnConvBackwardData_Begin(
        VEDNN_PARAMS_CONV_BACKWARD_DATA );
vednnConvBackwardDataImpls * vednnConvBackwardData_Next(
        vednnConvBackwardDataImpls* current,
        VEDNN_PARAMS_CONV_BACKWARD_DATA );

vednnConvBackwardFilterImpls * vednnConvBackwardFilter_Begin(
        VEDNN_PARAMS_CONV_BACKWARD_FILTER );
vednnConvBackwardFilterImpls * vednnConvBackwardFilter_Next(
        vednnConvBackwardFilterImpls* current,
        VEDNN_PARAMS_CONV_BACKWARD_FILTER );
//@}
#endif
#if 0
/** \group add dynamic redirection of impls at runtime
 * Most runtime-checks of data parameters simply return the same
 * list element.  If data alignment is no good, then at runtime
 * we dispatch to an alternate impl */
//@{
//
/** \fn vednnConvForwardImpls * vednnConvForward_Begin(
        VEDNN_PARAMS_CONV_FORWARD );
 * find \b first [best? fastest?] {okfn, impl} in list
 * such that \c okfn yields VEDNN_SUCCESS.
 * \return list terminator (all-NULLs) if none. */

/** \fn vednnConvForwardImpls * vednnConvForward_Next(
 *          vednnConvForwardImpls* current,
 *          VEDNN_PARAMS_CONV_FORWARD )
 * Return next available implementation, after \c current list item.
 * return list terminator (all-NULLs) if none.
 * This impl is based ONLY on convolution parameters.
 * \pre \c current points within vednnConvForwardList[]
 */

/** \fn vednnConvForwardImpls * vednnConvForward_realNext(
        vednnConvForwardImpls* current,
        VEDNN_PARAMS_CONV_FORWARD,
        VEDNN_DATARG_CONV_FORWARD );
 * Runtime check of current + data for ptr alignment.
 * - Note: we assume Params have been checked
 *   - i.e. \c current was obtained from a _Begin or _Next
 *
 * - if data ptr alignment of \c current is ok, return \c current
 * - o/w iterate and return next impl which is ok with both params + data
 * - return list terminator (all-NULLs) if none.
 *
 * Typically we just return \c current, because there is no runtime
 * check on pointer alignment.
 *
 * Use this, instead of _Run when you need to grab the name of the
 * actual impl that was used, \e before actually executing a timing loop.
 *
 * \pre \c current points within vednnConvForwardList[]
 * \post it is really OK to run the returned list impl
 */

/** \fn vednnConvForward_out_t vednnConvForward_Run(
        vednnConvForwardImpls* current,
        VEDNN_PARAMS_CONV_FORWARD,
        VEDNN_DATARG_CONV_FORWARD );
 * runs current [if possible], else the next fully-compatible impl.
 * Assumes \c current is compatible with conv params,
 * updates \c current if there are data ptr alignment issues,
 * and then runs the operation.
 *
 * Always run \c current via a _Run call.
 *
 * You should never invoke \c current->impl directly, because this skips
 * some wrapperization that might do OpenMP parallelization.
 *
 * \return {actual,status}, where actual is usually current, except
 *         when a data ptr alignment check failed and a [next] actual
 *         impl had to run instead.
 */        

/** run-time dispatch, based on additional data-pointer checks.
 * Default behavior is simply <tt>return current</tt>.
 * o.w. we continue forward from \c current and return the
 * first impl that passes its runtime checks (if any).
 *
 * So instead of invoking (cfi=vednnConvForward_Next)->impl directly,
 * you do 2 steps:
 * ```
 * nxt = vednnConvForward_Begin(...); // or _Next(...)
 * nxt = vednnConvForward_rtNext(nxt,FWD_DATA); // usually rt_nxt == nxt
 * FTRACE_BEGIN(rt_nxt->name)
 * rt_nxt->impl( CONVX_FWDB_ORDER(FWD_PARMS,FWD_DATA) ); // or so (dep on bias)
 * FTRACE_END(rt_nxt->name)
 * ```
 * We require getting \c rt_nxt so that you can (say) FTRACE with a string of the
 * \e actual rt impl that ran.
 *
 * \c nxt is always precalculated based just on FWD_PARMS
 * \c rt_nxt now includes runtime ok-ness with FWD_DATA too.
 *
 * This is so a \e single layer might sometimes be called with correctly
 * aligned data, sometimes without, and still the 'best' impl gets run.
 */
vednnConvForwardImpls * vednnConvForward_rtok(
        vednnConvForwardImpls* current,
        VEDNN_DATARG_CONV_FORWARD );

//@}
#endif
#ifdef __cplusplus //{
}
#endif
// vim: et ts=4 sw=4 cindent cino=^=l0,\:0,N-s syntax=cpp.doxygen
#endif // VEDNNCONVOLUTIONLISTS_H
