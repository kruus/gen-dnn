
#ifndef SRC_VEDNNCONVOLUTIONADDBIAS_H_
#define SRC_VEDNNCONVOLUTIONADDBIAS_H_

#include "vednn.h"

#ifdef __cplusplus
extern "C" {
#endif
typedef
vednnError_t (*vednnConvForwardAddBias_t) (
    const vednnTensorParam_t * restrict 	pParamIn,
    const void * restrict 			pDataIn,
    const vednnFilterParam_t * restrict 	pParamKernel,
    const void * restrict 			pDataKernel,
    const vednnBiasParam_t * restrict 		pParamBias,
    const void * restrict 			pDataBias,
    const vednnConvolutionParam_t * restrict 	pParamConv,
    const vednnTensorParam_t * restrict 	pParamOut,
    void * restrict 				pDataOut
) ;

#if 1

#define VEDNN_FUNC_CNVFWB( SUFFIX ) \
	vednnConvolutionForwardAddBias_direct_##SUFFIX
#define VEDNN_DECL_CNVFWB( SUFFIX ) \
vednnError_t VEDNN_FUNC_CNVFWB(SUFFIX) ( \
    const vednnTensorParam_t * restrict 	pParamIn, \
    const void * restrict 			pDataIn, \
    const vednnFilterParam_t * restrict 	pParamKernel, \
    const void * restrict 			pDataKernel, \
    const vednnBiasParam_t * restrict 		pParamBias, \
    const void * restrict 			pDataBias, \
    const vednnConvolutionParam_t * restrict 	pParamConv, \
    const vednnTensorParam_t * restrict 	pParamOut, \
    void * restrict 				pDataOut \
) ;

VEDNN_DECL_CNVFWB(default);
VEDNN_DECL_CNVFWB(dil1_str1_padsame);
VEDNN_DECL_CNVFWB(dil1_str1_pad0_ker1);
VEDNN_DECL_CNVFWB(dil1_str1_pad0_ker1_c1024x);
VEDNN_DECL_CNVFWB(dil1_str1_padsame_ker3);
VEDNN_DECL_CNVFWB(dil1_str1_padsame_ker3_c1);
VEDNN_DECL_CNVFWB(dil1_str1_padsame_ker3_c1_owU128);
VEDNN_DECL_CNVFWB(dil1_str1_padsame_ker3_c1024x);
// local additions
VEDNN_DECL_CNVFWB(default2);

#else
vednnError_t
vednnConvolutionForwardAddBias_direct_default(
    const vednnTensorParam_t * restrict 	pParamIn,
    const void * restrict 			pDataIn,
    const vednnFilterParam_t * restrict 	pParamKernel,
    const void * restrict 			pDataKernel,
    const vednnBiasParam_t * restrict 		pParamBias,
    const void * restrict 			pDataBias,
    const vednnConvolutionParam_t * restrict 	pParamConv,
    const vednnTensorParam_t * restrict 	pParamOut,
    void * restrict 				pDataOut
) ;

vednnError_t
vednnConvolutionForwardAddBias_direct_default2(
    const vednnTensorParam_t * restrict 	pParamIn,
    const void * restrict 			pDataIn,
    const vednnFilterParam_t * restrict 	pParamKernel,
    const void * restrict 			pDataKernel,
    const vednnBiasParam_t * restrict 		pParamBias,
    const void * restrict 			pDataBias,
    const vednnConvolutionParam_t * restrict 	pParamConv,
    const vednnTensorParam_t * restrict 	pParamOut,
    void * restrict 				pDataOut
) ;

vednnError_t
vednnConvolutionForwardAddBias_direct_dil1_str1_padsame(
    const vednnTensorParam_t * restrict 	pParamIn,
    const void * restrict 			pDataIn,
    const vednnFilterParam_t * restrict 	pParamKernel,
    const void * restrict 			pDataKernel,
    const vednnBiasParam_t * restrict 		pParamBias,
    const void * restrict 			pDataBias,
    const vednnConvolutionParam_t * restrict 	pParamConv,
    const vednnTensorParam_t * restrict 	pParamOut,
    void * restrict 				pDataOut
) ;

vednnError_t
vednnConvolutionForwardAddBias_direct_dil1_str1_pad0_ker1(
    const vednnTensorParam_t * restrict 	pParamIn,
    const void * restrict 			pDataIn,
    const vednnFilterParam_t * restrict 	pParamKernel,
    const void * restrict 			pDataKernel,
    const vednnBiasParam_t * restrict 		pParamBias,
    const void * restrict 			pDataBias,
    const vednnConvolutionParam_t * restrict 	pParamConv,
    const vednnTensorParam_t * restrict 	pParamOut,
    void * restrict 				pDataOut
) ;

vednnError_t
vednnConvolutionForwardAddBias_direct_dil1_str1_pad0_ker1_c1024x(
    const vednnTensorParam_t * restrict 	pParamIn,
    const void * restrict 			pDataIn,
    const vednnFilterParam_t * restrict 	pParamKernel,
    const void * restrict 			pDataKernel,
    const vednnBiasParam_t * restrict 		pParamBias,
    const void * restrict 			pDataBias,
    const vednnConvolutionParam_t * restrict 	pParamConv,
    const vednnTensorParam_t * restrict 	pParamOut,
    void * restrict 				pDataOut
) ;

vednnError_t
vednnConvolutionForwardAddBias_direct_dil1_str1_padsame_ker3(
    const vednnTensorParam_t * restrict 	pParamIn,
    const void * restrict 			pDataIn,
    const vednnFilterParam_t * restrict 	pParamKernel,
    const void * restrict 			pDataKernel,
    const vednnBiasParam_t * restrict 		pParamBias,
    const void * restrict 			pDataBias,
    const vednnConvolutionParam_t * restrict 	pParamConv,
    const vednnTensorParam_t * restrict 	pParamOut,
    void * restrict 				pDataOut
) ;

vednnError_t
vednnConvolutionForwardAddBias_direct_dil1_str1_padsame_ker3_c1(
    const vednnTensorParam_t * restrict 	pParamIn,
    const void * restrict 			pDataIn,
    const vednnFilterParam_t * restrict 	pParamKernel,
    const void * restrict 			pDataKernel,
    const vednnBiasParam_t * restrict 		pParamBias,
    const void * restrict 			pDataBias,
    const vednnConvolutionParam_t * restrict 	pParamConv,
    const vednnTensorParam_t * restrict 	pParamOut,
    void * restrict 				pDataOut
) ;

vednnError_t
vednnConvolutionForwardAddBias_direct_dil1_str1_padsame_ker3_c1_owU128(
    const vednnTensorParam_t * restrict 	pParamIn,
    const void * restrict 			pDataIn,
    const vednnFilterParam_t * restrict 	pParamKernel,
    const void * restrict 			pDataKernel,
    const vednnBiasParam_t * restrict 		pParamBias,
    const void * restrict 			pDataBias,
    const vednnConvolutionParam_t * restrict 	pParamConv,
    const vednnTensorParam_t * restrict 	pParamOut,
    void * restrict 				pDataOut
) ;

vednnError_t
vednnConvolutionForwardAddBias_direct_dil1_str1_padsame_ker3_c1024x(
    const vednnTensorParam_t * restrict 	pParamIn,
    const void * restrict 			pDataIn,
    const vednnFilterParam_t * restrict 	pParamKernel,
    const void * restrict 			pDataKernel,
    const vednnBiasParam_t * restrict 		pParamBias,
    const void * restrict 			pDataBias,
    const vednnConvolutionParam_t * restrict 	pParamConv,
    const vednnTensorParam_t * restrict 	pParamOut,
    void * restrict 				pDataOut
) ;
#endif

#ifdef __cplusplus
}//extern "C"
#endif
#endif /* SRC_VEDNNCONVOLUTIONADDBIAS_H_ */
