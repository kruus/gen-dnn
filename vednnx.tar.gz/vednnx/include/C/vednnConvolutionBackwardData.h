
#ifndef SRC_VEDNNCONVOLUTIONBACKWARDDATA_H_
#define SRC_VEDNNCONVOLUTIONBACKWARDDATA_H_

#include "vednn.h"

#ifdef __cplusplus
extern "C" {
#endif
// file, function and arg names have only minor variation
#define VEDNN_FUNC_CNVBKD( SUFFIX ) vednnConvolutionBackwardData_direct_##SUFFIX

#define VEDNN_DECL_CNVBKD( SUFFIX ) \
vednnError_t VEDNN_FUNC_CNVBKD(SUFFIX) ( \
        const vednnTensorParam_t * restrict        pParamGradOut, \
        const void * restrict                      pDataGradOut, \
        const vednnFilterParam_t * restrict        pParamKernel, \
        const void * restrict                      pDataKernel, \
        const vednnConvolutionParam_t * restrict   pParamConv, \
        const vednnTensorParam_t * restrict        pParamGradIn, \
        void * restrict                            pDataGradIn \
        )

typedef
vednnError_t (*vednnConvBackwardData_t) (
        const vednnTensorParam_t * restrict        pParamGradOut,
        const void * restrict                      pDataGradOut,
        const vednnFilterParam_t * restrict        pParamKernel,
        const void * restrict                      pDataKernel,
        const vednnConvolutionParam_t * restrict   pParamConv,
        const vednnTensorParam_t * restrict        pParamGradIn,
        void * restrict                            pDataGradIn
        ) ;

VEDNN_DECL_CNVBKD(default);
VEDNN_DECL_CNVBKD(default2);
VEDNN_DECL_CNVBKD(iwU128);
VEDNN_DECL_CNVBKD(dil1_str1);
VEDNN_DECL_CNVBKD(dil1_str1_iwU128);
VEDNN_DECL_CNVBKD(dil1_str1_pad0_ker3_iwU128);
VEDNN_DECL_CNVBKD(dil1_str1_pad0_ker3_iw2XU256_ow2X_ioaligned);
VEDNN_DECL_CNVBKD(dil1_str1_pad0_ker3_iw2XU32_ow2X_ioaligned);
VEDNN_DECL_CNVBKD(dil1_str1_padsame);
VEDNN_DECL_CNVBKD(dil1_str1_padsame_ker1);
VEDNN_DECL_CNVBKD(dil1_str1_padsame_ker2);
VEDNN_DECL_CNVBKD(dil1_str1_padsame_ker3);
VEDNN_DECL_CNVBKD(dil1_str1_padsame_ker5);
#ifdef __cplusplus
}//extern "C"
#endif
#endif /* SRC_VEDNNCONVOLUTIONBACKWARDDATA_H_ */
