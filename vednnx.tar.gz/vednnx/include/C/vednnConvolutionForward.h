
#ifndef SRC_VEDNNCONVOLUTIONFORWARD_H_
#define SRC_VEDNNCONVOLUTIONFORWARD_H_

#include "vednn.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef
vednnError_t (*vednnConvForward_t)(
    const vednnTensorParam_t * restrict 	pParamIn,
    const void * restrict 			pDataIn,
    const vednnFilterParam_t * restrict 	pParamKernel,
    const void * restrict 			pDataKernel,
    const vednnConvolutionParam_t * restrict 	pParamConv,
    const vednnTensorParam_t * restrict 	pParamOut,
    void * restrict 				pDataOut) ;

// file, function and arg names have only minor variation
#define VEDNN_FUNC_CNVFWD( SUFFIX ) vednnConvolutionForward_direct_##SUFFIX

/** low-level implementations. */
#define VEDNN_DECL_CNVFWD( SUFFIX ) \
vednnError_t VEDNN_FUNC_CNVFWD(SUFFIX) ( \
    const vednnTensorParam_t * restrict 	pParamIn, \
    const void * restrict 			pDataIn, \
    const vednnFilterParam_t * restrict 	pParamKernel, \
    const void * restrict 			pDataKernel, \
    const vednnConvolutionParam_t * restrict 	pParamConv, \
    const vednnTensorParam_t * restrict 	pParamOut, \
    void * restrict 				pDataOut \
)

VEDNN_DECL_CNVFWD(default);
VEDNN_DECL_CNVFWD(defaultA);
VEDNN_DECL_CNVFWD(alt);
VEDNN_DECL_CNVFWD(default2);
VEDNN_DECL_CNVFWD(default2p);
VEDNN_DECL_CNVFWD(default3);
VEDNN_DECL_CNVFWD(default3b);
VEDNN_DECL_CNVFWD(vecC);
VEDNN_DECL_CNVFWD(owU128);
VEDNN_DECL_CNVFWD(owU128A);
VEDNN_DECL_CNVFWD(dil1_pad0);
VEDNN_DECL_CNVFWD(dil1_pad0A);
VEDNN_DECL_CNVFWD(dil1_pad0_owU128);
VEDNN_DECL_CNVFWD(dil1_pad0_owU128A);
VEDNN_DECL_CNVFWD(dil1_pad0_ker1);
VEDNN_DECL_CNVFWD(dil1_pad0_ker1A);
VEDNN_DECL_CNVFWD(dil1_pad0_owU128_ker1);
VEDNN_DECL_CNVFWD(dil1_pad0_owU128_ker1A);
VEDNN_DECL_CNVFWD(dil1_str1_pad0_ker1);
VEDNN_DECL_CNVFWD(dil1_str1_pad0_ker1A);
VEDNN_DECL_CNVFWD(dil1_str1_pad0);
VEDNN_DECL_CNVFWD(dil1_str1_pad0A);
VEDNN_DECL_CNVFWD(dil1_str1_pad0_owU128);
VEDNN_DECL_CNVFWD(dil1_str1_pad0_owU128A);
VEDNN_DECL_CNVFWD(dil1_str1_pad0_ker3_iw2XU256_ow2X_ioaligned);
VEDNN_DECL_CNVFWD(dil1_str1_padsame);
VEDNN_DECL_CNVFWD(dil1_str1_padsameA); // try fastdiv
VEDNN_DECL_CNVFWD(dil1_str1_padsameB); // try masked FMA
VEDNN_DECL_CNVFWD(dil1_str1_padsameAB); // both above mods
VEDNN_DECL_CNVFWD(dil1_str1_padsame_ker3);
VEDNN_DECL_CNVFWD(dil1_str1_padsame_ker3A);
VEDNN_DECL_CNVFWD(dil1_str1_padsame_ker3_c1);
VEDNN_DECL_CNVFWD(dil1_str1_padsame_ker3_c1A);
VEDNN_DECL_CNVFWD(dil1_str1_padsame_ker3_c1_owU128);
VEDNN_DECL_CNVFWD(dil1_str1_padsame_ker3_c1_owU128A);
VEDNN_DECL_CNVFWD(dil1_str1_padsame_ker3_c1024x);
VEDNN_DECL_CNVFWD(dil1_str1_padsame_ker3_c1024xA);
VEDNN_DECL_CNVFWD(dil1_str1_padsame_ker5);
VEDNN_DECL_CNVFWD(dil1_str1_padsame_ker5A);
VEDNN_DECL_CNVFWD(dil1_str1_padsame_ker5_owU128);
VEDNN_DECL_CNVFWD(dil1_str1_padsame_ker5_owU128A);
VEDNN_DECL_CNVFWD(dil1_str1_padsame_ker2);
VEDNN_DECL_CNVFWD(dil1_str1_padsame_ker2A);
VEDNN_DECL_CNVFWD(gendnn);

#ifdef __cplusplus
}//extern "C"
#endif
// vim: et ts=4 sw=4 cindent cino=^=l0,\:0,N-s syntax=cpp.doxygen
#endif /* SRC_VEDNNCONVOLUTION_H_ */
