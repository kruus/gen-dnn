#ifndef SRC_VEDNNCONVOLUTIONBACKWARDFILTER_H_
#define SRC_VEDNNCONVOLUTIONBACKWARDFILTER_H_

#include "vednn.h"

#ifdef VEDNN_USE_OPENMP
#include <stdint.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif
#define VEDNN_FUNC_CNVBKF( SUFFIX ) vednnConvolutionBackwardFilter_direct_##SUFFIX

#ifdef VEDNN_USE_OPENMP
#define VEDNN_DECL_CNVBKF( SUFFIX ) \
    vednnError_t VEDNN_FUNC_CNVBKF(SUFFIX) ( \
            const vednnTensorParam_t * restrict 	 pParamIn, \
            const void * restrict 			         pDataIn, \
            const vednnTensorParam_t * restrict 	 pParamGradOut, \
            const void * restrict 			         pDataGradOut, \
            const vednnConvolutionParam_t * restrict pParamConv, \
            const vednnFilterParam_t * restrict 	 pParamGradKernel, \
            void * restrict 				         pDataGradKernel \
            , const int64_t				beginOChannel \
            , const int64_t				nOChannel \
            )
#else
#define VEDNN_DECL_CNVBKF( SUFFIX ) \
    vednnError_t VEDNN_FUNC_CNVBKF(SUFFIX) ( \
            const vednnTensorParam_t * restrict 	 pParamIn, \
            const void * restrict 			         pDataIn, \
            const vednnTensorParam_t * restrict 	 pParamGradOut, \
            const void * restrict 			         pDataGradOut, \
            const vednnConvolutionParam_t * restrict pParamConv, \
            const vednnFilterParam_t * restrict 	 pParamGradKernel, \
            void * restrict 				         pDataGradKernel \
            /*, const int64_t				beginOChannel*/ \
            /*, const int64_t				nOChannel*/ \
            )
#endif // VEDNN_USE_OPENMP

typedef
vednnError_t (*vednnConvBackwardFilter_t) (
        const vednnTensorParam_t * restrict 	 pParamIn,
        const void * restrict 			         pDataIn,
        const vednnTensorParam_t * restrict 	 pParamGradOut,
        const void * restrict 			         pDataGradOut,
        const vednnConvolutionParam_t * restrict pParamConv,
        const vednnFilterParam_t * restrict 	 pParamGradKernel,
        void * restrict 				         pDataGradKernel
#ifdef VEDNN_USE_OPENMP
        , const int64_t				beginOChannel
        , const int64_t				nOChannel
#endif
        ) ;

VEDNN_DECL_CNVBKF(default);
VEDNN_DECL_CNVBKF(default2);
VEDNN_DECL_CNVBKF(dil1_pad0); // .cc?
VEDNN_DECL_CNVBKF(dil1_pad0_ker1);
VEDNN_DECL_CNVBKF(dil1_pad0_ker1_owU32);
VEDNN_DECL_CNVBKF(dil1_pad0_ker1_ohwU64);
VEDNN_DECL_CNVBKF(dil1_pad0_ker1_ohwU128);
VEDNN_DECL_CNVBKF(dil1_pad0_owU32); // .cc?
VEDNN_DECL_CNVBKF(dil1_pad0_owU128);
VEDNN_DECL_CNVBKF(owU128);
VEDNN_DECL_CNVBKF(dil1_pad0_ker3_owU32);
VEDNN_DECL_CNVBKF(dil1_pad0_ker3_owU128);
VEDNN_DECL_CNVBKF(dil1_str1_pad0_ker3_ow2X_iw2XU256_igoaligned);
VEDNN_DECL_CNVBKF(dil1_str1_padsame);
VEDNN_DECL_CNVBKF(dil1_str1_padsame_ker1);
VEDNN_DECL_CNVBKF(dil1_str1_padsame_ker3);
VEDNN_DECL_CNVBKF(dil1_str1_padsame_ker3_ohwU256);
VEDNN_DECL_CNVBKF(dil1_str1_padsame_ker3_owU128);
VEDNN_DECL_CNVBKF(dil1_str1_padsame_ker5);
VEDNN_DECL_CNVBKF(dil1_str1_padsame_ker5_owU128);
VEDNN_DECL_CNVBKF(dil1_str1_padsame_ker2);
VEDNN_DECL_CNVBKF(dil1_str1_padsame_ker2_owU128);
#ifdef __cplusplus
}//extern "C"
#endif
// vim: et ts=4 sw=4 cindent cino=^=l0,\:0,N-s
#endif /* SRC_VEDNNCONVOLUTIONBACKWARDFILTER_H_ */
